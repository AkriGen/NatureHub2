import { Component } from '@angular/core';

@Component({
  selector: 'app-skincare',
  standalone: false,
  
  templateUrl: './skincare.component.html',
  styleUrl: './skincare.component.css'
})
export class SkincareComponent {

}
