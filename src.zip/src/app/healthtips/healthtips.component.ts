import { Component } from '@angular/core';

@Component({
  selector: 'app-healthtips',
  standalone: false,
  
  templateUrl: './healthtips.component.html',
  styleUrl: './healthtips.component.css'
})
export class HealthtipsComponent {

}
